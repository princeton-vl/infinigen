void computeColor(float fx, float fy, uchar *pix);
